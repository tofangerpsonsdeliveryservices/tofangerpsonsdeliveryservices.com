
import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles.css';

function App(){
 return <div>
 <header className="hero">
 <img src="/logo.png" className="logo"/>
 <h1>TOFANGERP & SONS DELIVERY SERVICES</h1>
 <p>Reliable Transport | Secure Storage | Smart Communication</p>
 </header>
 <section><h2>About Us</h2><p>37+ years of logistics, transport, storage and communication services across Papua New Guinea.</p></section>
 <section><h2>Services</h2><ul><li>Cargo Delivery</li><li>Airport Transfers</li><li>Heavy Equipment Transport</li><li>Secure Warehousing</li><li>Communication Services</li></ul></section>
 <section><h2>Management Team</h2><p>Mr. David Joe Kamo - Owner & Operator</p><p>Ms. Dorah Kamo - Office Manager</p></section>
 <section><h2>Request a Quote</h2><form><input placeholder="Name"/><input placeholder="Email"/><textarea placeholder="Requirements"></textarea></form></section>
 <section><h2>Contact</h2><p>+675 7933 5881</p><p>tofangerpsonsdeliveryservices@gmail.com</p></section>
 </div>
}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
